#!/usr/bin/env sh

autoreconf -ivf || exit 1
