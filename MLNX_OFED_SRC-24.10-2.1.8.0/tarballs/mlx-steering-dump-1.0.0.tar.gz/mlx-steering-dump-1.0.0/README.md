This is the HW/SW steering dump parsing tools.

 - For HWS please enter the hws directory and see readme file.
 - For SWS please enter the sws directory and see readme file.
