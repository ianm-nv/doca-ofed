#!/bin/sh

autoreconf -ivf || exit 1
