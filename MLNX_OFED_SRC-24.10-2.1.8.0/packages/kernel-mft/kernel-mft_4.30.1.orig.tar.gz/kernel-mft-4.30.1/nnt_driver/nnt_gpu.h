#ifndef NNT_GPU_H
#define NNT_GPU_H

int is_gpu_pci_device(u_int16_t pci_device_id);

#endif // NNT_GPU_H