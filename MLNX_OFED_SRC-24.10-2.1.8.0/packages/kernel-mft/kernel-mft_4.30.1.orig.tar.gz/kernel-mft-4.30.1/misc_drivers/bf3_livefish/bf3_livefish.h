#ifndef BF3_LIVEFISH_H
#define BF3_LIVEFISH_H


#define DRIVER_VERSION      1.0
#define STRINGIFY(s)        #s
#define CRSPACE_SIZE        (2 * 1024 * 1024)

#endif // BF3_LIVEFISH_H
