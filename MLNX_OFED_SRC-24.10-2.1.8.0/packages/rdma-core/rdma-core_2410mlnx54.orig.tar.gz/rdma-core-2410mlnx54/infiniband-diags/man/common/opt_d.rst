.. Define the common option -d

-d
        raise the IB debugging level.
        May be used several times (-ddd or -d -d -d).

