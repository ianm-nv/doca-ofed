.. Define the common option -C

**-C, --Ca <ca_name>**    use the specified ca_name.

