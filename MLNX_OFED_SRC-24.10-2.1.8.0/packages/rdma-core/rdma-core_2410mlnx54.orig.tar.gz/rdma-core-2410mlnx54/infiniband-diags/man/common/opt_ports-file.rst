.. Define the common option --ports-file

**--ports-file <ports-file>**   Specify a ports file.

        This file contains multiple source and destination lid or guid pairs. See FILES section.

