.. Define the common option -G

**--port-guid, -G <port_guid>**  Specify a port_guid

